// 首页：定位/搜索/分类/排序/单列列表
const nav = require('../../utils/nav.js');
const ui = require('../../utils/ui.js');

const ITEMS = {
  hot: [
    { id: 1, icon: '书', title: '高等数学教材 · 上册', price: '¥45', cond: '九成新', place: '宿舍区', cat: '书籍教材' },
    { id: 2, icon: '器', title: '机械键盘 87 键', price: '¥120', cond: '八成新', place: '实验楼', cat: '数码' },
    { id: 3, icon: '灯', title: '护眼台灯 · 可调光', price: '¥30', cond: '九成新', place: '宿舍区', cat: '生活用品' },
    { id: 4, icon: '乐', title: '民谣吉他 41 寸', price: '¥260', cond: '八成新', place: '艺术楼', cat: '生活用品' },
    { id: 5, icon: '卷', title: '考研英语真题合集', price: '¥25', cond: '九五成新', place: '图书馆', cat: '书籍教材' },
    { id: 6, icon: '键', title: '无线鼠标 + 鼠标垫', price: '¥35', cond: '八成新', place: '宿舍区', cat: '数码' },
    { id: 7, icon: '衣', title: '运动卫衣 · L 码', price: '¥55', cond: '九五成新', place: '宿舍区', cat: '服饰鞋包' },
    { id: 8, icon: '鞋', title: '帆布鞋 · 42 码', price: '¥60', cond: '八成新', place: '宿舍区', cat: '服饰鞋包' },
    { id: 9, icon: '动', title: '碳素羽毛球拍 ×2', price: '¥80', cond: '九成新', place: '体育场', cat: '运动器材' },
    { id: 10, icon: '书', title: '电路分析基础 · 第四版', price: '¥38', cond: '九五成新', place: '图书馆', cat: '书籍教材' },
    { id: 11, icon: '器', title: '蓝牙音箱 · 便携款', price: '¥75', cond: '八成新', place: '宿舍区', cat: '数码' },
    { id: 12, icon: '动', title: '瑜伽垫 · 加厚防滑', price: '¥28', cond: '全新', place: '宿舍区', cat: '运动器材' }
  ]
};
ITEMS.new = [ITEMS.hot[4], ITEMS.hot[0], ITEMS.hot[3], ITEMS.hot[2], ITEMS.hot[5], ITEMS.hot[1], ITEMS.hot[11], ITEMS.hot[8], ITEMS.hot[7], ITEMS.hot[10], ITEMS.hot[6], ITEMS.hot[9]];

// ===== 成色 / 地点 排序权重 =====
const COND_RANK = { '九五成新': 4, '九成新': 3, '八成新': 2, '七成新': 1 };
const PLACE_RANK = { '宿舍区': 1, '图书馆': 2, '实验楼': 3, '艺术楼': 4, '体育场': 5 };
const priceNum = (p) => { const m = String(p).replace(/[^\d.]/g, ''); return m ? parseFloat(m) : 0; };

Page(ui.toneAware({
  data: {
    loc: '砚湖大学',
    locating: false,
    kw: '',
    searched: false,
    tag: '综合',
    tags: ['综合', '价格', '成色', '地点'],
    cat: '',
    subTab: '热门推荐',
    cats: [
      { ch: '数', label: '数码' }, { ch: '书', label: '书籍教材' },
      { ch: '用', label: '生活用品' }, { ch: '衣', label: '服饰鞋包' },
      { ch: '动', label: '运动器材' }
    ],
    list: ITEMS.hot
  },
  onLoad() {
    // 页面内已有大标题，原生导航栏标题留空，避免两行标题打架
    this._apply(''); // 合并用户新发布条目，首屏即可展示（照片功能）
  },
  onTab(e) {
    const url = e.detail.url;
    if (url.indexOf('/pages/home/') > -1) return;
    nav.switchTo(url);
  },

  // ===== 任务②：学校名可点击 → 微信定位接口 =====
  // 预留接口：getLocation 成功后应再经逆地理编码解析校名；解析依赖地图服务
  //（开发成本），故当前拿到坐标仍沿用默认校区名，仅打通定位调用链路。
  pickLoc() {
    if (this.data.locating) return;
    if (!wx.getLocation) { // 定位能力不可用时的预留出口
      wx.showToast({ title: '当前环境不支持定位（预留接口）', icon: 'none' });
      return;
    }
    this.setData({ locating: true });
    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        this.setData({ locating: false });
        const campus = this._resolveCampus(res); // TODO: 接入逆地理编码后返回真实校名
        this.setData({ loc: campus || this.data.loc });
        wx.showToast({ title: campus ? ('已定位：' + campus) : '已获取定位（校名解析预留）', icon: 'none' });
      },
      fail: () => {
        this.setData({ locating: false });
        wx.showToast({ title: '定位未授权，暂用当前校区', icon: 'none' });
      }
    });
  },
  _resolveCampus(res) {
    // 预留：坐标 → 校园名称（需后端 / 地图 Key，暂返回空走默认校区）
    void res;
    return '';
  },

  // ===== 任务③：搜索按钮点击 / 回车 → 关键词筛选商品列表 =====
  onKw(e) { this.setData({ kw: e.detail.value }); },
  doSearch() {
    const kw = (this.data.kw || '').trim();
    this._apply(kw);
    wx.showToast({
      title: kw ? ('找到 ' + this.data.list.length + ' 件「' + kw + '」相关') : '已显示全部商品',
      icon: 'none'
    });
  },
  clearSearch() {
    if (!this.data.searched) return;
    this.setData({ kw: '' });
    this._apply('');
  },

  // ===== 任务①：筛选标签 → 实际变更商品列表 =====
  pickTag(e) {
    const t = e.currentTarget.dataset.t;
    this.setData({ tag: t });
    this._apply((this.data.kw || '').trim());
  },

  // 统一列表计算：基准数据(双Tab) → 关键词过滤 → 标签排序
  _apply(kw) {
    const base = this.data.subTab === '热门推荐' ? ITEMS.hot : ITEMS.new;
    const mine = (getApp().globalData && getApp().globalData.userItems) || [];
    let list = mine.concat(base.slice()); // 新发布条目置顶（照片功能）
    if (kw) list = list.filter((it) => ((it.title || '') + (it.cond || '') + (it.place || '') + (it.cat || '') + (it.icon || '')).indexOf(kw) > -1);
    if (this.data.cat) list = list.filter((it) => it.cat === this.data.cat);
    const tag = this.data.tag;
    if (tag === '价格') list.sort((a, b) => priceNum(a.price) - priceNum(b.price));
    else if (tag === '成色') list.sort((a, b) => (COND_RANK[b.cond] || 0) - (COND_RANK[a.cond] || 0));
    else if (tag === '地点') list.sort((a, b) => (PLACE_RANK[a.place] || 0) - (PLACE_RANK[b.place] || 0));
    // 综合：保持基准顺序（关键词命中优先已在过滤中体现）
    // WXML 表达式不支持函数调用，价格展示串在此预计算（¥ 由模板单独渲染）
    list = list.map((it) => Object.assign({}, it, {
      k: ui.catKey(it.cat),
      priceText: String(it.price == null ? '' : it.price).replace(/[¥￥\s]/g, '')
    }));
    this.setData({ list, searched: !!kw });
  },

  pickCat(e) {
    const l = e.currentTarget.dataset.l;
    const cat = this.data.cat === l ? '' : l; // 再点一次取消筛选
    this.setData({ cat });
    this._apply((this.data.kw || '').trim());
    wx.showToast({ title: cat ? '已筛选 · ' + cat : '已显示全部', icon: 'none' });
  },
  pickSub(e) {
    const t = e.currentTarget.dataset.t;
    if (t === this.data.subTab) return;
    this.setData({ subTab: t });
    this._apply((this.data.kw || '').trim());
  },
  openItem(e) {
    const d = e.currentTarget.dataset.d;
    nav.go('/pages/detail/detail?title=' + encodeURIComponent(d.title) + '&price=' + encodeURIComponent(d.price) + '&cond=' + encodeURIComponent(d.cond) + '&cat=' + encodeURIComponent(d.cat || '') + '&place=' + encodeURIComponent(d.place) + '&id=' + encodeURIComponent(d.id == null ? '' : d.id));
  }
}));
