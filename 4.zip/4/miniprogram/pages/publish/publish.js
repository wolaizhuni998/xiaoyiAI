// 发布页：发布闲置商品（走统一接口层，mock 返回本地 id）
const nav = require('../../utils/nav.js');
const api = require('../../utils/api.js');
const ui = require('../../utils/ui.js');

Page(ui.toneAware({
  data: {
    form: { title: '', cat: '', price: '', cond: '', place: '' },
    photos: [],
    cats: ['数码', '书籍教材', '生活用品', '服饰鞋包', '运动器材'],
    conds: ['全新', '九五成新', '九成新', '八成新', '七成新'],
    places: ['宿舍区', '教学区', '实验楼', '图书馆', '体育馆'],
    aiBusy: false,
    aiInfo: null
  },
  onLoad() { },
  onTab(e) {
    const url = e.detail.url;
    if (url.indexOf('/pages/publish/') > -1) return;
    nav.switchTo(url);
  },
  onField(e) {
    const k = e.currentTarget.dataset.k;
    this.setData({ ['form.' + k]: e.detail.value });
  },
  onCat(e) { this.setData({ 'form.cat': this.data.cats[e.detail.value] }); },
  onCond(e) { this.setData({ 'form.cond': this.data.conds[e.detail.value] }); },
  onPlace(e) { this.setData({ 'form.place': this.data.places[e.detail.value] }); },

  // ===== 照片：选图 / 删图 / 预览 =====
  addPhoto() {
    const left = 6 - this.data.photos.length;
    if (left <= 0) return;
    wx.chooseMedia({
      count: left,
      mediaType: ['image'],
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const add = (res.tempFiles || []).map((f) => f.tempFilePath).filter(Boolean);
        this.setData({ photos: this.data.photos.concat(add).slice(0, 6) });
      }
    });
  },
  removePhoto(e) {
    const list = this.data.photos.slice();
    list.splice(e.currentTarget.dataset.i, 1);
    this.setData({ photos: list });
  },
  previewPhoto(e) {
    wx.previewImage({ current: e.currentTarget.dataset.src, urls: this.data.photos });
  },

  // ===== 拍照填表：照片 + 关键词 → 类目/标题/成色/参考价一并填好，可手动改 =====
  aiFill() {
    if (this.data.aiBusy) return;
    if (!this.data.photos.length) {
      wx.showToast({ title: '先选 1 张照片再识别', icon: 'none' });
      return;
    }
    this.setData({ aiBusy: true });
    api.post('/ai/analyze', { photos: this.data.photos.length, kw: (this.data.form.title || '').trim() })
      .then((r) => {
        const f = Object.assign({}, this.data.form, {
          title: r.title, price: String(r.price), cond: r.cond, cat: r.cat
        });
        this.setData({ form: f, aiInfo: r, aiBusy: false });
        wx.showToast({ title: '已填入表单', icon: 'success' });
      })
      .catch((e) => {
        this.setData({ aiBusy: false });
        wx.showToast({ title: (e && e.msg) || '识别失败', icon: 'none' });
      });
  },

  submit() {
    if (!api.isLoggedIn()) {
      wx.showToast({ title: '发布前请先手机号登录', icon: 'none' });
      setTimeout(() => { api.goLogin(); }, 700);
      return;
    }
    const f = this.data.form;
    if (!f.title || !f.price) { wx.showToast({ title: '请填写物品名称与价格', icon: 'none' }); return; }
    const item = {
      id: 'u' + Date.now(),
      title: f.title,
      price: (f.price + '').indexOf('¥') > -1 ? f.price : '¥' + f.price,
      cond: f.cond || '九成新',
      place: f.place || '宿舍区',
      cat: f.cat || '',
      photos: this.data.photos.slice()
    };
    // 走统一接口层 /goods/publish：mock 返回本地 id，真实后端返回真实 id；失败也先本地演示不卡流程
    const finish = (id) => {
      if (id) item.id = id;
      getApp().globalData.userItems.unshift(item);
      wx.showToast({ title: '已发布', icon: 'success' });
      setTimeout(() => { nav.switchTo('/pages/home/home'); }, 700);
    };
    api.post('/goods/publish', {
      title: item.title, price: item.price, cond: item.cond, place: item.place,
      cat: item.cat, desc: '', imgs: item.photos
    }).then((r) => finish(r && r.id)).catch(() => finish());
  },
  cancel() { nav.back(); }
}));
