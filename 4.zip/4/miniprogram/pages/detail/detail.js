// 商品详情：从首页进入；联系卖家 → 进入聊天
const nav = require('../../utils/nav.js');
const ui = require('../../utils/ui.js');

// 微信不自动 decodeURIComponent 查询参数，这里统一解码（防 %E6%... 乱码）
const dec = (v) => { try { return decodeURIComponent(v || ''); } catch (e) { return v || ''; } };

Page(ui.toneAware({
  data: {
    item: { title: '校园好物', price: '¥0', cond: '九成新', place: '宿舍区', cat: '' },
    photos: [],
    k: 'other',
    priceText: '¥0',
    sellerCh: '同',
    faved: false,
    desc: '闲置物品，功能完好，诚心出售。可在校内当面交易，欢迎留言。'
  },
  onLoad(opt) {
    const item = {
      title: dec(opt && opt.title) || '校园好物',
      price: dec(opt && opt.price) || '¥0',
      cond: dec(opt && opt.cond) || '九成新',
      place: dec(opt && opt.place) || '宿舍区',
      cat: dec(opt && opt.cat) || ''
    };
    // 照片：按 id 从全局用户条目取照片组，无则回退类目图标
    let photos = [];
    const gid = dec(opt && opt.id);
    if (gid) {
      const mine = (getApp().globalData && getApp().globalData.userItems) || [];
      const hit = mine.filter((x) => String(x.id) === gid)[0];
      if (hit && hit.photos && hit.photos.length) photos = hit.photos;
    }
    // WXML 表达式不支持函数调用，价格展示串在 JS 里算好（无有效数字时显示面议）
    const digits = String(item.price).replace(/[^\d.]/g, '');
    const priceText = digits && parseFloat(digits) > 0 ? item.price : '面议';
    this.setData({ item, photos, k: ui.catKey(item.cat), priceText });
  },
  previewPhoto(e) { wx.previewImage({ current: e.currentTarget.dataset.src, urls: this.data.photos }); },
  contact() { nav.go('/pages/chat/chat?from=' + encodeURIComponent('卖家 · 同窗甲')); },
  fav() {
    const faved = !this.data.faved;
    this.setData({ faved });
    wx.showToast({ title: faved ? '已收藏' : '已取消收藏', icon: 'none' });
  }
}));
